// HTML to APK Pro - Permissions Helper
document.addEventListener('deviceready', function() {
  console.log('✅ Cordova ready');

  // 📷 الكاميرا
  window.takePicture = function(cb) {
    navigator.camera.getPicture(function(data) {
      if (cb) cb(data);
    }, function(err) { console.error('Camera error:', err); }, {
      quality: 80, destinationType: Camera.DestinationType.DATA_URL,
      sourceType: Camera.PictureSourceType.CAMERA
    });
  };

  // 🔔 الإشعارات
  window.sendNotification = function(title, text) {
    cordova.plugins.notification.local.schedule({
      title: title || 'إشعار', text: text || 'مرحباً!', foreground: true
    });
  };
});
