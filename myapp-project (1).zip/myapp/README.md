# MyApp

تطبيق تم إنشاؤه بواسطة **HTML to APK Pro**

## 📱 معلومات التطبيق
- **الاسم:** MyApp
- **الحزمة:** com.example.myapp
- **الإصدار:** 1.0.0

## 🔐 الصلاحيات المفعّلة
- ✅ camera
- ✅ notification
- ✅ storage
- ✅ internet

## 🚀 كيفية الحصول على APK

### الطريقة 1: GitHub Actions (الأسهل من الهاتف)
1. أنشئ حساباً على [github.com](https://github.com)
2. أنشئ مستودعاً جديداً
3. ارفع كل ملفات هذا المشروع
4. اذهب إلى **Actions** → **Build APK** → **Run workflow**
5. انتظر 3-5 دقائق
6. حمّل APK من **Artifacts**

### الطريقة 2: PWABuilder
1. افتح [pwabuilder.com](https://www.pwabuilder.com)
2. ارفع ملفات www
3. اختر Android
4. حمّل APK

### الطريقة 3: على كمبيوتر
```bash
npm install -g cordova
cd myapp
cordova platform add android
cordova build android
```

الملف الناتج: `platforms/android/app/build/outputs/apk/debug/app-debug.apk`

---
صُنع بـ ⚡ HTML to APK Pro
